"use client";

import { useEffect, useState, useRef } from "react";
import { motion, useInView } from "framer-motion";
import Carousel from "@/components/Carousel";
import Navbar from "@/components/Navbar";
import FluidBackground from "@/components/FluidBackground";
import ScrollIndicator from "@/components/ScrollIndicator";
import CustomerExperience from "@/components/CustomerExperience";
import AIChatbot from "@/components/AIChatbot";

const services = [
  {
    id: 1,
    title: "Branding",
    description: "Create a unique identity that resonates with your audience and sets you apart from competitors.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-10 w-10">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09Z" />
      </svg>
    ),
    color: "bg-orange-500"
  },
  {
    id: 2,
    title: "Development",
    description: "Build robust, scalable applications with modern technologies and best practices.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-10 w-10">
        <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 7.5l3 2.25-3 2.25m4.5 0h3m-9 8.25h13.5A2.25 2.25 0 0 0 21 18V6a2.25 2.25 0 0 0-2.25-2.25H5.25A2.25 2.25 0 0 0 3 6v12a2.25 2.25 0 0 0 2.25 2.25Z" />
      </svg>
    ),
    color: "bg-blue-600"
  },
  {
    id: 3,
    title: "Motion",
    description: "Add life to your designs with fluid animations and engaging micro-interactions.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-10 w-10">
        <path strokeLinecap="round" strokeLinejoin="round" d="m3.75 13.5 10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75Z" />
      </svg>
    ),
    color: "bg-orange-500"
  },
  {
    id: 4,
    title: "UI/UX",
    description: "Create intuitive, beautiful interfaces that delight users and improve conversion rates.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-10 w-10">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.53 16.122a3 3 0 0 0-5.78 1.128 2.25 2.25 0 0 1-2.4 2.245 4.5 4.5 0 0 0 8.4-2.245c0-.399-.078-.78-.22-1.128Zm0 0a15.998 15.998 0 0 0 3.388-1.62m-5.043-.025a15.994 15.994 0 0 1 1.622-3.395m3.42 3.42a15.995 15.995 0 0 0 4.764-4.648l3.876-5.814a1.151 1.151 0 0 0-1.597-1.597L14.146 6.32a15.996 15.996 0 0 0-4.649 4.763m3.42 3.42a6.776 6.776 0 0 0-3.42-3.42" />
      </svg>
    ),
    color: "bg-blue-600"
  }
];

export default function Home() {
  const [isLoading, setIsLoading] = useState(true);
  const servicesRef = useRef(null);
  const isInView = useInView(servicesRef, { once: true, amount: 0.3 });

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 100, damping: 15 } }
  };

  return (
    <main className="relative min-h-screen w-full overflow-x-hidden bg-black text-white">
      {isLoading ? (
        <div className="fixed inset-0 flex items-center justify-center bg-black">
          <div className="animate-pulse text-3xl font-bold text-white">
            FOX STUDIO
          </div>
        </div>
      ) : (
        <>
          <ScrollIndicator />
          <FluidBackground />
          <Navbar />
          <AIChatbot />

          {/* Hero Section */}
          <section className="relative z-10 mx-auto max-w-screen-xl px-4 pb-16 pt-28 md:px-8">
            <h1 className="mb-6 text-4xl font-bold md:text-6xl">
              Designing a{" "}
              <span className="bg-gradient-to-r from-blue-600 to-orange-500 bg-clip-text text-transparent">
                Brighter Tomorrow.
              </span>
            </h1>
            <p className="mb-12 max-w-2xl text-lg text-gray-300">
              Creating digital experiences that blend innovative design with cutting-edge technology. We bring your vision to life with precision and creativity.
            </p>
            <Carousel />
          </section>

          {/* Customer Experience Section */}
          <CustomerExperience />

          {/* Services Section */}
          <section ref={servicesRef} className="relative z-10 py-20">
            <div className="mx-auto max-w-screen-xl px-4 md:px-8">
              <div className="mb-12 text-center">
                <motion.h2
                  className="mb-4 text-3xl font-bold md:text-4xl"
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                  transition={{ duration: 0.5 }}
                >
                  Our Services
                </motion.h2>
                <motion.div
                  className="mx-auto mb-6 h-1 w-20 bg-orange-500"
                  initial={{ width: 0 }}
                  animate={isInView ? { width: 80 } : { width: 0 }}
                  transition={{ duration: 0.7, delay: 0.3 }}
                />
                <motion.p
                  className="mx-auto max-w-2xl text-gray-300"
                  initial={{ opacity: 0 }}
                  animate={isInView ? { opacity: 1 } : { opacity: 0 }}
                  transition={{ duration: 0.5, delay: 0.4 }}
                >
                  We offer a comprehensive suite of services to elevate your digital presence and create meaningful connections with your audience.
                </motion.p>
              </div>

              <motion.div
                className="grid gap-8 md:grid-cols-2 lg:grid-cols-4"
                variants={container}
                initial="hidden"
                animate={isInView ? "show" : "hidden"}
              >
                {services.map((service) => (
                  <motion.div
                    key={service.id}
                    className={`card-hover-effect rounded-xl p-6 ${service.color} bg-opacity-10 backdrop-blur-sm border border-white/10`}
                    variants={item}
                    whileHover={{
                      y: -10,
                      boxShadow: "0 10px 25px -5px rgba(59, 130, 246, 0.5)"
                    }}
                  >
                    <div className="mb-4">{service.icon}</div>
                    <h3 className="mb-2 text-xl font-semibold">{service.title}</h3>
                    <p className="text-gray-300">{service.description}</p>
                  </motion.div>
                ))}
              </motion.div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="relative z-10 py-20">
            <div className="mx-auto max-w-screen-xl px-4 md:px-8">
              <motion.div
                className="overflow-hidden rounded-2xl bg-gradient-to-r from-blue-600 to-orange-500 p-8 md:p-12"
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true, amount: 0.3 }}
              >
                <div className="flex flex-col items-center justify-between gap-8 md:flex-row">
                  <div>
                    <h2 className="mb-4 text-2xl font-bold text-white md:text-3xl">Ready to transform your digital presence?</h2>
                    <p className="max-w-md text-white/80">Let's collaborate to create something extraordinary that elevates your brand and engages your audience.</p>
                  </div>
                  <motion.button
                    className="rounded-full bg-white px-8 py-3 text-lg font-semibold text-blue-600 shadow-lg"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    Get Started
                  </motion.button>
                </div>
              </motion.div>
            </div>
          </section>

          {/* Footer */}
          <footer className="relative z-10 border-t border-white/10 py-12">
            <div className="mx-auto max-w-screen-xl px-4 md:px-8">
              <div className="flex flex-col items-center justify-between md:flex-row">
                <div className="mb-6 flex items-center md:mb-0">
                  <span className="text-xl font-bold">FOX STUDIO</span>
                  <div className="ml-2 h-5 w-5 rounded-full bg-orange-500" />
                </div>
                <div className="flex space-x-6">
                  <a href="#about" className="text-gray-300 hover:text-white">About</a>
                  <a href="#services" className="text-gray-300 hover:text-white">Services</a>
                  <a href="#work" className="text-gray-300 hover:text-white">Work</a>
                  <a href="#contact" className="text-gray-300 hover:text-white">Contact</a>
                </div>
              </div>
              <div className="mt-8 text-center text-sm text-gray-400">
                &copy; 2025 Fox Studio. All rights reserved.
              </div>
            </div>
          </footer>
        </>
      )}
    </main>
  );
}

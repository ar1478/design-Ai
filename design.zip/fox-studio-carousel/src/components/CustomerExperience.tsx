"use client";

import { useState, useRef } from "react";
import { motion, useInView } from "framer-motion";
import ChatMessage from "./ChatMessage";

export default function CustomerExperience() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });
  const [selectedTab, setSelectedTab] = useState(0);

  const tabs = [
    {
      id: "omnichannel",
      label: "Expérience omnicanale",
      content: "Transformez les données complexes des clients en informations exploitables. Offrez des expériences exceptionnelles sur tous les canaux.",
      stats: [
        { label: "Augmentation de la fidélisation", value: "+28%" },
        { label: "Amélioration de la satisfaction", value: "+35%" }
      ]
    },
    {
      id: "feedback",
      label: "Retours client",
      content: "Recueillez et analysez les commentaires des clients provenant de plusieurs points de contact pour améliorer votre service.",
      stats: [
        { label: "Taux de réponse", value: "68%" },
        { label: "Résolution des problèmes", value: "+42%" }
      ]
    },
    {
      id: "analytics",
      label: "Analyse prédictive",
      content: "Tirez parti de l'IA avancée pour analyser les données et prendre des décisions proactives pour répondre aux besoins des clients.",
      stats: [
        { label: "Prévention des problèmes", value: "+47%" },
        { label: "Précision des recommandations", value: "89%" }
      ]
    }
  ];

  const chatMessages = [
    {
      message: "Bonjour Marie, j'ai remarqué que vous avez eu des difficultés à finaliser votre commande sur notre site. Je voudrais vous aider à résoudre ce problème.",
      backgroundColor: "#f8f9fa"
    },
    {
      message: "Bonjour Steve, j'ai vu que vous aviez des problèmes pour réserver sur notre site. Je voulais vous appeler pour voir si je pouvais vous aider.",
      backgroundColor: "#f0f7ff"
    },
    {
      message: "Bonjour Thomas, notre système a détecté plusieurs tentatives infructueuses de connexion à votre compte. Puis-je vous aider à récupérer l'accès?",
      backgroundColor: "#fff8f0"
    }
  ];

  return (
    <section className="relative z-10 py-24 overflow-hidden" ref={ref}>
      <div className="absolute -top-40 -right-40 w-96 h-96 bg-orange-500 rounded-full opacity-10 blur-[100px]" />

      <div className="container mx-auto px-4">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl md:text-5xl font-bold mb-4">
            Stoppez net les problèmes des clients
          </h2>
          <div className="w-20 h-1 bg-orange-500 mx-auto my-6"></div>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            Identifiez les points de friction, les lacunes en matière d'expérience et les tendances avant leur accentuation. Aidez les équipes à prendre des mesures pertinentes.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            className="flex flex-col gap-6"
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="flex gap-2 mb-4 border-b border-gray-800">
              {tabs.map((tab, index) => (
                <button
                  key={tab.id}
                  className={`px-5 py-3 font-medium relative ${
                    selectedTab === index
                      ? "text-white"
                      : "text-gray-400 hover:text-gray-300"
                  }`}
                  onClick={() => setSelectedTab(index)}
                >
                  {tab.label}
                  {selectedTab === index && (
                    <motion.div
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-orange-500"
                      layoutId="tab-indicator"
                    />
                  )}
                </button>
              ))}
            </div>

            <div className="bg-gray-900 bg-opacity-40 rounded-xl p-8 backdrop-blur-sm border border-gray-800">
              <h3 className="text-2xl font-bold mb-4">{tabs[selectedTab].label}</h3>
              <p className="text-gray-300 mb-6">{tabs[selectedTab].content}</p>

              <div className="grid grid-cols-2 gap-4">
                {tabs[selectedTab].stats.map((stat, index) => (
                  <div key={index} className="bg-gray-800 bg-opacity-50 rounded-lg p-4">
                    <p className="text-sm text-gray-400">{stat.label}</p>
                    <p className="text-2xl font-bold text-orange-400">{stat.value}</p>
                  </div>
                ))}
              </div>

              <div className="mt-8">
                <button className="bg-gradient-to-r from-blue-600 to-orange-500 text-white px-6 py-3 rounded-full font-medium hover:from-blue-700 hover:to-orange-600 transition-all duration-300">
                  En savoir plus
                </button>
              </div>
            </div>
          </motion.div>

          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <ChatMessage
              message={chatMessages[2].message}
              backgroundColor={chatMessages[2].backgroundColor}
              waveformColor="linear-gradient(90deg, #0062ff, #ff7e00, #0099ff)"
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
              <div className="bg-gray-900 bg-opacity-40 rounded-xl p-6 backdrop-blur-sm border border-gray-800">
                <div className="mb-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-orange-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold">Feedback en temps réel</h3>
                <p className="text-gray-400 text-sm mt-2">Collectez des commentaires sur tous les canaux et identifiez rapidement les problèmes.</p>
              </div>

              <div className="bg-gray-900 bg-opacity-40 rounded-xl p-6 backdrop-blur-sm border border-gray-800">
                <div className="mb-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold">Analyse digitale</h3>
                <p className="text-gray-400 text-sm mt-2">Suivez chaque interaction numérique pour identifier les problèmes potentiels.</p>
              </div>

              <div className="bg-gray-900 bg-opacity-40 rounded-xl p-6 backdrop-blur-sm border border-gray-800">
                <div className="mb-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-orange-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold">Intelligence prédictive</h3>
                <p className="text-gray-400 text-sm mt-2">Anticipez les besoins des clients avant qu'ils ne les expriment.</p>
              </div>

              <div className="bg-gray-900 bg-opacity-40 rounded-xl p-6 backdrop-blur-sm border border-gray-800">
                <div className="mb-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold">Centre de contact intégré</h3>
                <p className="text-gray-400 text-sm mt-2">Transformez votre centre d'appels en un avantage concurrentiel.</p>
              </div>
            </div>
          </motion.div>
        </div>

        <motion.div
          className="mt-24 bg-gradient-to-r from-blue-600 to-orange-500 rounded-2xl p-10 relative overflow-hidden"
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <div className="absolute top-0 left-0 w-full h-full bg-black opacity-10" />
          <div className="absolute -top-24 -right-24 w-64 h-64 bg-blue-300 rounded-full opacity-20 blur-[50px]" />

          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
            <div>
              <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">
                Envie de voir la Plateforme en action?
              </h3>
              <p className="text-white/80 max-w-xl">
                Découvrez comment notre solution peut transformer l'expérience de vos clients et améliorer vos résultats commerciaux.
              </p>
            </div>

            <div className="flex flex-col md:flex-row gap-4">
              <button className="bg-white text-blue-700 px-6 py-3 rounded-full font-medium hover:bg-gray-100 transition-all duration-300">
                Voir la démo
              </button>
              <button className="bg-transparent border border-white text-white px-6 py-3 rounded-full font-medium hover:bg-white/10 transition-all duration-300">
                Essai gratuit
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

"use client";

import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";

interface ChatMessageProps {
  message: string;
  waveformColor?: string;
  backgroundColor?: string;
  onPlay?: () => void;
}

export default function ChatMessage({
  message,
  waveformColor = "linear-gradient(90deg, #0062ff, #ff7e00, #0099ff)", // Updated to use orange and blue colors
  backgroundColor = "#fff8f0", // Updated background color
  onPlay
}: ChatMessageProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [waveformBars, setWaveformBars] = useState<number[]>([]);
  const animationRef = useRef<number>();

  useEffect(() => {
    // Generate random waveform with 40 bars
    const generateWaveform = () => {
      const bars = Array.from({ length: 40 }, () =>
        Math.floor(Math.random() * 100)
      );
      return bars;
    };

    setWaveformBars(generateWaveform());
  }, []);

  const togglePlay = () => {
    const newState = !isPlaying;
    setIsPlaying(newState);

    if (onPlay) {
      onPlay();
    }

    if (newState) {
      animateWaveform();
    } else {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    }
  };

  const animateWaveform = () => {
    const animate = () => {
      setWaveformBars(prev => {
        return prev.map(() => Math.floor(Math.random() * 100));
      });
      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);
  };

  // Clean up animation on unmount
  useEffect(() => {
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  return (
    <div
      className="flex flex-col max-w-md rounded-xl overflow-hidden shadow-lg"
      style={{ backgroundColor }}
    >
      <div className="p-6">
        <p className="text-gray-700 text-base mb-8">{message}</p>

        <div className="flex items-center">
          <div className="flex-1 h-16 flex items-center justify-between">
            {waveformBars.map((height, i) => (
              <motion.div
                key={i}
                className="w-1 mx-[1px] rounded-full"
                style={{
                  background: waveformColor,
                  height: isPlaying ? `${Math.max(5, height)}%` : "40%",
                }}
                initial={{ height: "40%" }}
                animate={{
                  height: isPlaying ? `${Math.max(5, height)}%` : "40%",
                }}
                transition={{ duration: 0.1 }}
              />
            ))}
          </div>
        </div>
      </div>

      <div className="px-6 py-4 bg-white flex justify-between items-center">
        <button
          onClick={togglePlay}
          className="text-blue-600 font-medium flex items-center"
        >
          {isPlaying ? (
            <>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Pause
            </>
          ) : (
            <>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Play
            </>
          )}
        </button>

        <div className="text-gray-500 text-sm">0:32</div>
      </div>
    </div>
  );
}

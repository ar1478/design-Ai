"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import Link from "next/link";

const navLinks = [
  { name: "Brand", href: "#brand", color: "bg-orange-500" },
  { name: "Development", href: "#development", color: "bg-blue-600" },
  { name: "Motion", href: "#motion", color: "bg-orange-500" },
  { name: "UI/UX", href: "#uiux", color: "bg-blue-600" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <motion.header
      className={`fixed left-0 right-0 top-0 z-50 px-4 py-4 transition-all duration-300 ${
        scrolled ? "bg-black/80 backdrop-blur-md" : "bg-transparent"
      }`}
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, delay: 0.1 }}
    >
      <div className="mx-auto flex max-w-screen-xl items-center justify-between">
        <motion.div
          className="text-2xl font-bold"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Link href="/" className="group flex items-center gap-2">
            <div className="relative h-8 w-8 overflow-hidden rounded-full bg-gradient-to-r from-blue-600 to-orange-500">
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-blue-600 to-orange-500"
                animate={{
                  rotate: [0, 360],
                }}
                transition={{
                  duration: 8,
                  repeat: Infinity,
                  ease: "linear"
                }}
              />
            </div>
            <span className="relative">
              FOX STUDIO
              <motion.span
                className="absolute bottom-0 left-0 h-[2px] w-0 bg-orange-500"
                initial={{ width: "0%" }}
                whileHover={{ width: "100%" }}
                transition={{ duration: 0.3 }}
              />
            </span>
          </Link>
        </motion.div>

        <nav>
          <ul className="flex space-x-1 md:space-x-2">
            {navLinks.map((link, index) => (
              <motion.li key={link.name}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * (index + 1), duration: 0.5 }}
              >
                <Link
                  href={link.href}
                  className="group relative block px-3 py-2 text-sm font-medium"
                >
                  <span className="relative z-10">
                    {link.name}
                    <motion.span
                      className="absolute -bottom-1 left-0 h-[2px] w-0 bg-blue-500"
                      initial={{ width: "0%" }}
                      whileHover={{ width: "100%" }}
                      transition={{ duration: 0.2 }}
                    />
                  </span>
                  <motion.span
                    className={`absolute bottom-0 left-0 h-0 w-full ${link.color} opacity-10`}
                    initial={{ height: 0 }}
                    whileHover={{ height: "100%" }}
                    transition={{ duration: 0.3 }}
                  />
                </Link>
              </motion.li>
            ))}
          </ul>
        </nav>

        <motion.div
          className="hidden cursor-pointer rounded-full border border-white/20 px-4 py-2 text-sm font-medium md:block"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          whileHover={{
            backgroundColor: "rgba(255, 255, 255, 0.1)",
            scale: 1.05
          }}
        >
          Contact us
        </motion.div>
      </div>
    </motion.header>
  );
}

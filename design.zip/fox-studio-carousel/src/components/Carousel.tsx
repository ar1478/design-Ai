"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { motion, useAnimation } from "framer-motion";
import gsap from "gsap";

// Project Cards Data
const projectCards = [
  {
    id: 1,
    title: "Designing a Brighter Tomorrow",
    category: "Brand",
    color: "bg-blue-600",
    textColor: "text-white",
    imageUrl: "/card1.jpg"
  },
  {
    id: 2,
    title: "Making UI/UX Extraordinary",
    category: "Motion",
    color: "bg-pink-500",
    textColor: "text-white",
    imageUrl: "/card2.jpg"
  },
  {
    id: 3,
    title: "Development Excellence",
    category: "Development",
    color: "bg-green-500",
    textColor: "text-white",
    imageUrl: "/card3.jpg"
  },
  {
    id: 4,
    title: "Brand Evolution",
    category: "Brand",
    color: "bg-purple-500",
    textColor: "text-white",
    imageUrl: "/card4.jpg"
  },
];

const Carousel = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const carouselRef = useRef<HTMLDivElement>(null);
  const controls = useAnimation();

  const handleNext = useCallback(() => {
    setActiveIndex((prevIndex) => (prevIndex + 1) % projectCards.length);
  }, []);

  const handlePrev = useCallback(() => {
    setActiveIndex((prevIndex) => (prevIndex - 1 + projectCards.length) % projectCards.length);
  }, []);

  useEffect(() => {
    // Initialize GSAP animations
    const interval = setInterval(() => {
      handleNext();
    }, 5000);

    return () => clearInterval(interval);
  }, [handleNext]);

  // Animation logic
  useEffect(() => {
    controls.start({
      transition: { duration: 0.5 }
    });
  }, [controls]);

  const getCardPosition = (index: number) => {
    const diff = index - activeIndex;

    if (diff === 0) {
      return {
        zIndex: 30,
        x: 0,
        scale: 1,
        opacity: 1,
        rotateY: 0,
      };
    }

    if (diff === 1 || diff === -projectCards.length + 1) {
      return {
        zIndex: 20,
        x: '25%',
        scale: 0.9,
        opacity: 0.7,
        rotateY: 5,
      };
    }

    if (diff === -1 || diff === projectCards.length - 1) {
      return {
        zIndex: 20,
        x: '-25%',
        scale: 0.9,
        opacity: 0.7,
        rotateY: -5,
      };
    }

    if (diff > 1) {
      return {
        zIndex: 10,
        x: '50%',
        scale: 0.8,
        opacity: 0.4,
        rotateY: 10,
      };
    }

    return {
      zIndex: 10,
      x: '-50%',
      scale: 0.8,
      opacity: 0.4,
      rotateY: -10,
    };
  };

  return (
    <div className="relative mx-auto w-full max-w-6xl">
      <div className="relative h-[500px] w-full perspective-1000" ref={carouselRef}>
        {projectCards.map((card, index) => {
          const position = getCardPosition(index);

          return (
            <motion.div
              key={card.id}
              className="absolute left-1/2 top-0 h-full w-full max-w-2xl -translate-x-1/2 transform-gpu cursor-pointer overflow-hidden rounded-xl"
              initial={false}
              animate={{
                zIndex: position.zIndex,
                x: `calc(-50% + ${position.x})`,
                scale: position.scale,
                opacity: position.opacity,
                rotateY: position.rotateY,
              }}
              transition={{
                type: "spring",
                stiffness: 300,
                damping: 30,
              }}
              onClick={() => setActiveIndex(index)}
              style={{
                transformStyle: "preserve-3d",
              }}
            >
              <div
                className={`relative h-full w-full overflow-hidden ${card.color} p-8`}
              >
                <motion.div
                  className="absolute right-4 top-4 rounded-full bg-white/10 px-4 py-2 text-sm font-medium"
                  whileHover={{ backgroundColor: "rgba(255, 255, 255, 0.2)" }}
                >
                  {card.category}
                </motion.div>

                <div className="mt-12 flex h-full flex-col justify-between">
                  <div>
                    <motion.h3
                      className={`text-3xl font-bold ${card.textColor}`}
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.1, duration: 0.5 }}
                    >
                      {card.title}
                    </motion.h3>

                    <motion.div
                      className="mt-4 h-1 w-12 bg-white/50"
                      initial={{ width: 0 }}
                      animate={{ width: 48 }}
                      transition={{ delay: 0.3, duration: 0.5 }}
                    />
                  </div>

                  <motion.div
                    className="flex items-center gap-2"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.4, duration: 0.5 }}
                  >
                    <span className="text-sm opacity-80">View project</span>
                    <svg
                      width="20"
                      height="20"
                      viewBox="0 0 20 20"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M5 10H15M15 10L10 5M15 10L10 15"
                        stroke="currentColor"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </motion.div>
                </div>

                {index === activeIndex && (
                  <motion.div
                    className="absolute bottom-0 left-0 h-1.5 bg-white"
                    initial={{ width: "0%" }}
                    animate={{ width: "100%" }}
                    transition={{
                      duration: 5,
                      ease: "linear",
                      repeat: 1,
                      repeatType: "loop",
                    }}
                  />
                )}
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="mt-8 flex items-center justify-center gap-4">
        <motion.button
          className="flex h-12 w-12 items-center justify-center rounded-full border border-white/20 text-white"
          onClick={handlePrev}
          whileHover={{ scale: 1.1, backgroundColor: "rgba(255, 255, 255, 0.1)" }}
          whileTap={{ scale: 0.95 }}
        >
          <svg
            width="20"
            height="20"
            viewBox="0 0 20 20"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M12.5 15L7.5 10L12.5 5"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </motion.button>

        <div className="flex gap-2">
          {projectCards.map((card, index) => (
            <motion.button
              key={`dot-${card.id}`}
              className={`h-2 w-2 rounded-full ${
                index === activeIndex ? "bg-white" : "bg-white/30"
              }`}
              onClick={() => setActiveIndex(index)}
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }}
            />
          ))}
        </div>

        <motion.button
          className="flex h-12 w-12 items-center justify-center rounded-full border border-white/20 text-white"
          onClick={handleNext}
          whileHover={{ scale: 1.1, backgroundColor: "rgba(255, 255, 255, 0.1)" }}
          whileTap={{ scale: 0.95 }}
        >
          <svg
            width="20"
            height="20"
            viewBox="0 0 20 20"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M7.5 5L12.5 10L7.5 15"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </motion.button>
      </div>
    </div>
  );
}

export default Carousel;
